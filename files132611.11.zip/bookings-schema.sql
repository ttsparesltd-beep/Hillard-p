create table if not exists bookings (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid references customers(id) on delete cascade,
  vehicle_id uuid references vehicles(id) on delete cascade,
  repair_type text,
  description text not null,
  preferred_date date,
  phone text,
  photo_url text,
  status text,
  admin_notes text,
  created_at timestamptz default now()
);

alter table bookings enable row level security;

create policy bookings_own_data on bookings
  for all using (
    customer_id in (select id from customers where user_id = auth.uid())
  );
