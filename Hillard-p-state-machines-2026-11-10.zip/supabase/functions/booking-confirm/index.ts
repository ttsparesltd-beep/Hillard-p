// booking-confirm v2 — 10 Nov 2026
//
// The only way a booking moves pending → confirmed (see STATE_MACHINES.md).
//
//   GET  ?id=…               Never changes anything. Sends the browser to the
//                            confirm page on hillardperformance.com, where staff
//                            press a button. (Email link scanners and previews
//                            open links on their own, so a link must not confirm.)
//                            Falls back to the old confirm-on-open behaviour only
//                            while that page isn't deployed yet.
//   GET  ?id=…&format=json   Booking summary for the confirm page (no email/phone).
//   POST {id, date?}         Confirms. Only acts on a PENDING booking, so the
//                            customer is emailed exactly once. Everything sent to
//                            the customer comes from the database, never the URL.
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const FROM_EMAIL = 'noreply@hillardperformance.com'
const SITE = 'https://hillardperformance.com'
const CONFIRM_PAGE = `${SITE}/hillard-confirm.html`

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
}
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...cors, 'Content-Type': 'application/json' } })
const text = (b: string, status = 200) =>
  new Response(b, { status, headers: { ...cors, 'Content-Type': 'text/plain; charset=utf-8' } })

const esc = (s: unknown) => String(s ?? '').replace(/[&<>"']/g, c =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!))
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/

const db = () => createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)

// bookings has a foreign key to vehicles but not to customers, so the customer
// is fetched separately rather than embedded.
async function load(id: string) {
  const sb = db()
  const { data: b, error } = await sb.from('bookings')
    .select('id, status, preferred_date, confirmed_date, repair_type, customer_id, vehicles(registration, make, model)')
    .eq('id', id).maybeSingle()
  if (error) throw new Error(`booking lookup: ${error.message}`)
  if (!b) return null
  const { data: c } = b.customer_id
    ? await sb.from('customers').select('first_name, last_name, email').eq('id', b.customer_id).maybeSingle()
    : { data: null }
  return { ...b, customers: c } as any
}

const vehicleLabel = (v: any) => [v?.registration, [v?.make, v?.model].filter(Boolean).join(' ')].filter(Boolean).join(' — ')
const prettyDate = (d: string | null) => d
  ? new Date(d + 'T12:00:00').toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })
  : 'To be confirmed'

function summary(b: any) {
  return {
    id: b.id, status: b.status,
    customer: b.customers?.first_name || '',
    vehicle: vehicleLabel(b.vehicles),
    repair_type: b.repair_type,
    preferred_date: b.preferred_date,
    confirmed_date: b.confirmed_date
  }
}

async function confirm(id: string, date: string | null) {
  const before = await load(id)
  if (!before) return { ok: false, code: 404, error: 'Booking not found' }
  if (before.status !== 'pending') {
    return { ok: true, already: true, booking: summary(before) }
  }
  const patch: Record<string, unknown> = { status: 'confirmed' }
  patch.confirmed_date = date && ISO_DATE.test(date) ? date : before.preferred_date
  // Conditional update: two quick clicks can't both confirm (and both email).
  const { data: rows, error } = await db().from('bookings').update(patch)
    .eq('id', id).eq('status', 'pending').select('id')
  if (error) {
    const taken = /DATE_TAKEN|DATE_BLOCKED/.test(error.message)
    return { ok: false, code: 409, error: taken ? 'That date is already taken or blocked — pick another.' : error.message }
  }
  if (!rows?.length) return { ok: true, already: true, booking: summary((await load(id)) ?? before) }

  const b = await load(id)
  const email = b?.customers?.email
  let emailed = false
  if (email) emailed = await sendCustomerEmail(b)
  return { ok: true, already: false, emailed, booking: summary(b) }
}

async function sendCustomerEmail(b: any): Promise<boolean> {
  const firstName = esc(b.customers?.first_name || 'there')
  const vehicle = esc(vehicleLabel(b.vehicles))
  const job = esc(b.repair_type || 'Repair')
  const when = prettyDate(b.confirmed_date)
  const gd = (b.confirmed_date || '').replace(/-/g, '')
  const gcalUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(`${b.repair_type || 'Repair'} — Hillard Performance`)}&dates=${gd}/${gd}&details=${encodeURIComponent(`Your booking at Hillard Performance has been confirmed.\nVehicle: ${vehicleLabel(b.vehicles)}\nJob: ${b.repair_type || ''}`)}&location=${encodeURIComponent('Hillard Performance')}`
  const html = `
    <div style="font-family:sans-serif;max-width:520px;margin:0 auto;padding:32px 24px;background:#0a0a0b;color:#f0f0f4;border-radius:16px;">
      <img src="${SITE}/logo.png" style="height:52px;margin-bottom:32px;display:block;" alt="Hillard Performance"/>
      <div style="background:rgba(74,222,128,0.1);border:1px solid rgba(74,222,128,0.3);border-radius:12px;padding:16px 20px;margin-bottom:24px;">
        <div style="font-size:16px;font-weight:700;color:#4ade80;">&#10003; Booking Confirmed</div>
        <div style="font-size:13px;color:#a0a0b0;margin-top:2px;">We look forward to seeing you</div>
      </div>
      <p style="color:#a0a0b0;font-size:14px;line-height:1.7;margin:0 0 24px;">Hi ${firstName},<br>Your booking is confirmed. Here are the details:</p>
      <div style="background:#111114;border:1px solid #2a2a32;border-radius:12px;padding:20px;margin-bottom:24px;">
        <table style="width:100%;font-size:14px;border-collapse:collapse;">
          <tr><td style="color:#6b6b7a;padding:6px 0;width:40%;">Vehicle</td><td style="color:#f0f0f4;font-weight:600;">${vehicle}</td></tr>
          <tr><td style="color:#6b6b7a;padding:6px 0;">Job type</td><td style="color:#f0f0f4;">${job}</td></tr>
          <tr><td style="color:#6b6b7a;padding:6px 0;">Date</td><td style="color:#4ade80;font-weight:700;">${esc(when)}</td></tr>
        </table>
      </div>
      <a href="${gcalUrl}" target="_blank" style="display:block;text-align:center;background:#4a9eff;color:white;text-decoration:none;padding:14px 28px;border-radius:10px;font-weight:700;font-size:14px;letter-spacing:0.1em;margin-bottom:24px;">ADD TO GOOGLE CALENDAR</a>
      <p style="color:#a0a0b0;font-size:13px;line-height:1.7;margin:0 0 24px;">Need to reschedule or have any questions?<br>
        <a href="tel:01270295285" style="color:#e8291c;text-decoration:none;font-weight:600;">01270 295285</a></p>
      <div style="border-top:1px solid #2a2a32;padding-top:20px;"><p style="color:#5a5a6a;font-size:12px;margin:0;">Hillard Performance · <a href="${SITE}" style="color:#5a5a6a;">hillardperformance.com</a></p></div>
    </div>`
  try {
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${Deno.env.get('RESEND_API_KEY')}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: FROM_EMAIL, to: b.customers.email, subject: `Booking Confirmed — ${when}`, html })
    })
    console.log('confirm email', res.status)
    return res.ok
  } catch (e) { console.error('email failed', (e as Error).message); return false }
}

let pageLive: boolean | null = null
async function confirmPageLive(): Promise<boolean> {
  if (pageLive) return true
  try { pageLive = (await fetch(CONFIRM_PAGE, { method: 'HEAD', redirect: 'manual' })).ok } catch { pageLive = false }
  return pageLive
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  try {
    const url = new URL(req.url)

    if (req.method === 'POST') {
      const body = await req.json().catch(() => ({}))
      const id = String(body.id || '')
      if (!UUID.test(id)) return json({ ok: false, error: 'Missing or bad booking id' }, 400)
      const r: any = await confirm(id, body.date || null)
      return json(r, r.ok ? 200 : r.code || 500)
    }

    const id = url.searchParams.get('id') || ''
    if (!UUID.test(id)) return text('Missing or bad booking ID', 400)

    if (url.searchParams.get('format') === 'json') {
      const b = await load(id)
      return b ? json({ ok: true, booking: summary(b) }) : json({ ok: false, error: 'Booking not found' }, 404)
    }

    if (await confirmPageLive()) {
      return new Response(null, { status: 302, headers: { ...cors, Location: `${CONFIRM_PAGE}?id=${id}` } })
    }

    // Fallback until hillard-confirm.html is deployed: old behaviour, made safe.
    const r: any = await confirm(id, null)
    if (!r.ok) return text(`Could not confirm: ${r.error}`, r.code || 500)
    const b = r.booking
    return text(r.already
      ? `Already ${b.status.replace('_', ' ')} — ${b.vehicle}, ${prettyDate(b.confirmed_date || b.preferred_date)}. Nothing was changed and no email was sent.`
      : `Booking confirmed — ${b.vehicle}, ${b.repair_type || ''}, ${prettyDate(b.confirmed_date)}.\n${r.emailed ? 'The customer has been emailed.' : 'No customer email on file — let them know yourself.'}`)
  } catch (err) {
    console.error('booking-confirm error:', (err as Error).message)
    return text(`Error: ${(err as Error).message}`, 500)
  }
})
