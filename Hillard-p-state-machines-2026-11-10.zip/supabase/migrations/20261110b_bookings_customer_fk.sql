-- 10 Nov 2026 — bookings had no foreign key to customers, so PostgREST couldn't
-- embed customers(...) in the admin bookings/customers queries and both panels
-- loaded empty. 0 orphan rows at the time of applying. Applied live.
alter table bookings add constraint bookings_customer_id_fkey
  foreign key (customer_id) references customers(id) on delete set null;
create index if not exists bookings_customer_id_idx on bookings(customer_id);
notify pgrst, 'reload schema';
