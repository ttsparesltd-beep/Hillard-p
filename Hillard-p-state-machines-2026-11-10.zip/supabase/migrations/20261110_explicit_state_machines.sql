-- Explicit state machines — 10 Nov 2026
-- Makes the statuses the app already uses into rules the database enforces,
-- and keeps the "shadow" columns (confirmed_date, invoiced_at, paid_at) in step
-- with the status they belong to. See STATE_MACHINES.md.
-- Safe to re-run.

-- ── bookings: pending → confirmed → in_progress → completed  (any → cancelled)
update bookings set status = 'pending' where status is null;
alter table bookings alter column status set default 'pending';
alter table bookings alter column status set not null;
alter table bookings drop constraint if exists bookings_status_check;
alter table bookings add constraint bookings_status_check
  check (status in ('pending','confirmed','in_progress','completed','cancelled'));

create or replace function bookings_state_coherence() returns trigger
language plpgsql as $$
begin
  -- A confirmed booking always has a confirmed date (falls back to the requested day).
  if new.status in ('confirmed','in_progress','completed') and new.confirmed_date is null then
    new.confirmed_date := new.preferred_date;
  end if;
  return new;
end $$;
drop trigger if exists bookings_state_coherence on bookings;
create trigger bookings_state_coherence before insert or update on bookings
  for each row execute function bookings_state_coherence();
update bookings set confirmed_date = preferred_date
  where status in ('confirmed','in_progress','completed') and confirmed_date is null;

-- ── job_sheets: open → progress → done → invoiced   (archived_at is a separate flag)
update job_sheets set status = 'open' where status is null;
alter table job_sheets alter column status set default 'open';
alter table job_sheets alter column status set not null;
alter table job_sheets drop constraint if exists job_sheets_status_check;
alter table job_sheets add constraint job_sheets_status_check
  check (status in ('open','progress','done','invoiced'));

create or replace function job_sheets_state_coherence() returns trigger
language plpgsql as $$
begin
  -- A sheet pushed to Zoho is invoiced, whatever the dropdown said.
  if new.zoho_invoice_id is not null then new.status := 'invoiced'; end if;
  if new.status = 'invoiced' and new.invoiced_at is null then new.invoiced_at := now(); end if;
  return new;
end $$;
drop trigger if exists job_sheets_state_coherence on job_sheets;
create trigger job_sheets_state_coherence before insert or update on job_sheets
  for each row execute function job_sheets_state_coherence();

-- ── yard_cars: status set depends on the list; left_at is the end state
alter table yard_cars drop constraint if exists yard_cars_status_check;
alter table yard_cars add constraint yard_cars_status_check check (
  (list = 'workshop' and status in ('waiting','on_ramp','done')) or
  (list = 'breakers' and status in ('arrived','stripping','shell_gone'))
);

-- ── invoices: status mirrors Zoho; paid_at follows 'paid'
create or replace function invoices_paid_at() returns trigger
language plpgsql as $$
begin
  if new.status = 'paid' and new.paid_at is null then new.paid_at := now();
  elsif new.status is distinct from 'paid' then new.paid_at := null;
  end if;
  return new;
end $$;
drop trigger if exists invoices_paid_at on invoices;
create trigger invoices_paid_at before insert or update of status on invoices
  for each row execute function invoices_paid_at();

-- ── Self-documenting schema (read by people and agents via the table editor / list_tables)
comment on column bookings.status is
  'State machine: pending → confirmed → in_progress → completed; pending|confirmed|in_progress → cancelled. confirmed_date is auto-filled on confirm. See STATE_MACHINES.md';
comment on column job_sheets.status is
  'State machine: open → progress → done → invoiced. Setting zoho_invoice_id forces invoiced and stamps invoiced_at. archived_at is an independent hide flag. See STATE_MACHINES.md';
comment on column job_sheets.archived_at is 'Hidden from the work lists (not coming in / old). Independent of status.';
comment on column yard_cars.status is
  'workshop: waiting → on_ramp → done. breakers: arrived → stripping → shell_gone. left_at set = off the yard (final). See STATE_MACHINES.md';
comment on column yard_cars.left_at is 'Final state: car has left the yard. Rows with left_at are history.';
comment on column invoices.status is
  'Mirrors Zoho Books (sent, viewed, overdue, partially_paid, paid, void…). Sync never moves a row off paid. paid_at is stamped automatically. See STATE_MACHINES.md';
comment on column vehicles.removed_at is 'Soft delete: set = removed from the customer''s garage; re-adding the reg clears it.';
comment on column customers.user_id is 'Null = admin-created customer not yet claimed; set by trigger when someone signs up with this email.';
comment on column break_appraisals.status is 'Only ''open'' is used so far. verdict (BUY / NEGOTIATE / WALK) is computed in the page, not a state.';
